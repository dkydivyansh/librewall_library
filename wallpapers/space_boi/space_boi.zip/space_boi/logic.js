function updateClock() {
  // Array of day names
  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  
  // Get current date and time
  const now = new Date();
  
  // Get time components
  let hours = now.getHours();
  let minutes = now.getMinutes();
  let seconds = now.getSeconds();
  
  // Get the current day name
  const day = dayNames[now.getDay()];

  // --- 12-Hour Format Logic ---
  
  // Determine AM or PM
  const ampm = hours >= 12 ? 'PM' : 'AM';
  
  // Convert to 12-hour format
  hours = hours % 12;
  hours = hours ? hours : 12; // The hour '0' should be '12'

  // --- Add leading zeros ---
  
  // Add leading zero to hours if less than 10
  hours = hours < 10 ? '0' + hours : hours;
  // Add leading zero to minutes if less than 10
  minutes = minutes < 10 ? '0' + minutes : minutes;
  // Add leading zero to seconds if less than 10
  seconds = seconds < 10 ? '0' + seconds : seconds;

  // --- Display the clock ---
  
  // Combine into the final time string
  const timeString = `${hours}:${minutes}:${seconds} ${ampm}`;
  
  // Update the HTML elements
  document.getElementById('clock-time').textContent = timeString;
  document.getElementById('clock-day').textContent = day;
}

// Run the clock function immediately on load
updateClock();

// Run the clock function every second (1000 milliseconds)
setInterval(updateClock, 1000);